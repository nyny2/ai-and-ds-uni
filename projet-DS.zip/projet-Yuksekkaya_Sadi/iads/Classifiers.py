# -*- coding: utf-8 -*-

"""
Package: iads
File: Classifiers.py
Année: LU3IN026 - semestre 2 - 2025-2026, Sorbonne Université
"""

# Classfieurs implémentés en LU3IN026
# Version de départ : Février 2026

# Import de packages externes
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mtpl
import graphviz as gv
import seaborn as sns

import math
import time
import sys
import copy

from abc import ABC, abstractmethod

# ---------------------------

##################################################################
# la classe mere

class Classifier(ABC):
    """ Classe (abstraite) pour représenter un classifieur
        Attention: cette classe est ne doit pas être instanciée.
    """
    __nombre_crees: int = 0  # Variable de classe pour compter le nombre de classifiers créés
    
    def __init__(self, input_dimension):
        """ Constructeur de Classifier
            Argument:
                - intput_dimension (int) : dimension de la description des exemples
            Hypothèse : input_dimension > 0
        """
        Classifier.__nombre_crees += 1
        self.__ident = Classifier.__nombre_crees  # identifiant du classifieur (unique)
        self.__dimension = input_dimension
        
    def get_dimension(self):
        """ Accesseur de la variable __dimension 
        """
        return self.__dimension
        
    def __str__(self) -> str:
        """ rend une chaîne de caractères (méthode toString)
            Par exemple, pour afficher des informations sur l'objet 
        """
        return f'Classifier #{self.__ident} (d{self.__dimension})'
        
    @abstractmethod
    def train(self, desc_set, label_set) -> None:
        pass

    @abstractmethod
    def score(self, x) -> float:
        pass
    
    @abstractmethod
    def predict(self, x) -> int:
        pass

    def accuracy(self, desc_set, label_set) -> float:
        sum = 0
        nb = len(desc_set)
        for i in range(nb):
            if self.predict(desc_set[i]) == label_set[i]:
                sum += 1
        return sum / nb
        
##################################################################
# Classifier avec un biais b, donc de dimension : input_dimension+1

class ClassifierPerceptron(Classifier):
    """ Perceptron de Rosenblatt
    """
    def __init__(self, input_dimension, learning_rate=0.01, init=True, verbose=False):
        super().__init__(input_dimension)
        self.__learning = learning_rate

        if init:
            self.__w = np.zeros(input_dimension + 1)
        else:
            self.__w = (np.random.rand(input_dimension) * 2 - 1) * 0.001
            aleat = (np.random.rand() * 2 - 1) * 0.001
            self.__w = np.append(self.__w, aleat)
        
        self.__allw = [self.__w.copy()]

        if verbose:
            print(f"{super().__str__()}: initialisation (learning rate= {self.__learning}) w= {self.__w}")


    def train_step(self, desc_set, label_set, stabilised=False):
        nb_exemples = desc_set.shape[0]
        indices = np.arange(nb_exemples)
        np.random.shuffle(indices)

        for i in indices:
            d_x = desc_set[i]
            d_x = self.augmente(d_x)

            l_x = label_set[i]

            score = d_x @ self.__w

            if not stabilised:
                if score >= 0:
                    y_y = 1
                else:
                    y_y = -1
                
                if y_y != l_x:
                    self.__w += self.__learning * l_x * d_x
                    self.__allw.append(self.__w.copy())
            else:
                if score * l_x < 1:
                    self.__w += self.__learning * (l_x - score) * d_x
                    self.__allw.append(self.__w.copy())


    def __str__(self) -> str:
        return super().__str__() + f'w={self.__w}  epsilon={self.__learning}'

    def train(self, desc_set, label_set, nb_max=100, seuil=0.001, stabilised=False, verbose=False):
        diff = []
        nb_iter = 0
        for _ in range(nb_max):
            nb_iter += 1
            old_w = self.__w.copy()
            self.train_step(desc_set, label_set, stabilised=stabilised)
            new_w = self.__w.copy()
            norme = np.linalg.norm(new_w - old_w)
            diff.append(norme)
            if norme < seuil:
                break
        if verbose:
            print(f"train {self} : {nb_iter} appels à train_step")
        return diff

    def score(self, x):
        x = self.augmente(x)
        return x @ self.__w

    def predict(self, x):
        return 1 if self.score(x) >= 0 else -1

    def augmente(self, x):
        taille = x.shape
        if len(taille) == 1:
            return np.append(x, -1)
        col = -1 * np.ones((x.shape[0], 1))
        return np.append(x, col, axis=1)

    def get_allw(self):
        return self.__allw
        
##################################################################
# classifier sans biais

class ClassifierPerceptronTME3(Classifier):
    """ Perceptron de Rosenblatt (version TME3) """

    def __init__(self, input_dimension, learning_rate=0.01, init=True, verbose=False):
        super().__init__(input_dimension)
        
        self.__learning = learning_rate
        if init:
            self.__w = np.zeros(input_dimension)
        else:
            self.__w = (np.random.rand(input_dimension) * 2 - 1) * 0.001

        self.__allw = [self.__w.copy()]

        if verbose:
            print(f"{super().__str__()} Perceptron (TME3) : initialisation (learning rate= {self.__learning}) w= {self.__w}")

    def train_step(self, desc_set, label_set, stabilised=False):
        nb_exemples = desc_set.shape[0]
        indices = np.arange(nb_exemples)
        np.random.shuffle(indices)
        
        for i in indices:
            d_x = desc_set[i]
            l_x = label_set[i]
            
            score = d_x @ self.__w
            
            if not stabilised:
                y_y = 1 if score >= 0 else -1
                
                if y_y != l_x:
                    self.__w += self.__learning * l_x * d_x
                    self.__allw.append(self.__w.copy())
            else:
                if score * l_x < 1:
                    self.__w += self.__learning * (l_x - score) * d_x
                    self.__allw.append(self.__w.copy())

    def __str__(self) -> str:
        return f"{super().__str__()} Perceptron (TME3) - init (learning rate = {self.__learning} w= {self.__w}"

    def train(self, desc_set, label_set, nb_max=100, seuil=0.001, stabilised=False, verbose=False):
        diff = []
        nb_iter = 0
        for _ in range(nb_max):
            nb_iter += 1
            old_w = self.__w.copy()
            self.train_step(desc_set, label_set, stabilised=stabilised)
            new_w = self.__w.copy()
            norme = np.linalg.norm(new_w - old_w)
            diff.append(norme)
            if norme < seuil:
                break
        if verbose:
            print(f"train {super().__str__()} - PerceptronTME3 w= {self.__w} : {nb_iter} appels à train_step")
        return diff

    def score(self, x):
        return x @ self.__w

    def predict(self, x):
        return 1 if self.score(x) >= 0 else -1

    def get_allw(self):
        return self.__allw
        
##################################################################

class ClassifierKNN(Classifier):
    """ Classe pour représenter un classifieur par K plus proches voisins.
        Cette classe hérite de la classe Classifier
    """
    def __init__(self, input_dimension, k):
        """ Constructeur de Classifier
            Argument:
                - intput_dimension (int) : dimension d'entrée des exemples
                - k (int) : nombre de voisins à considérer
            Hypothèse : input_dimension > 0
        """
        super().__init__(input_dimension)  # Appel du constructeur de la classe mère
        self.__k= k
        # les 2 variables suivantes seront utilisées dans la méthode train()
        self.__desc_set= None   
        self.__labels_set= None

    def __str__(self) -> str:
        """ rend une chaîne de caractères (méthode toString)
            Par exemple, pour afficher des informations sur l'objet 
        """
        return super().__str__()+f' - k={self.__k}'

    def train(self, desc_set, label_set) -> None:
        """ Permet d'entrainer le modele sur l'ensemble donné
            desc_set: array avec des descriptions
            label_set: array avec les labels correspondants
            Hypothèse: desc_set et label_set ont le même nombre de lignes
        """        
        self.__desc_set=desc_set
        self.__labels_set=label_set

    def score(self,x) -> float:
        """ rend la proportion de +1 parmi les k ppv de x (valeur réelle)
            x: une description : un array
        """
        tab_dis=np.linalg.norm(self.__desc_set-x, axis=1)
        tab_ord=np.argsort(tab_dis)
        nbr_uns=0
    
        for i in range(self.__k):
            if  self.__labels_set[tab_ord[i]]==1:
                nbr_uns=nbr_uns+1
                
        p=nbr_uns/self.__k
        if p==0.5:
            return 0
        return 2*(p-0.5)
    
    def predict(self, x) -> int:
        """ rend la prediction sur x (-1 ou +1)
            x: une description : un array
        """
        s=self.score(x)
        if s<0:
            return -1
        return 1
        
##################################################################

def classe_majoritaire(Y):
    """ Y : (array) : array de labels
        rend la classe majoritaire ()
    """

    lab_un = np.unique(Y)
    maxx = 0
    for l in lab_un:
        taille = len(Y[Y == l])
        if taille > maxx:
            maxx = taille
            classe = l
    return classe
    
##################################################################

def shannon(P,k=2):
    """ list[Number] * int -> float
        Hypothèse: P est une distribution de probabilités et k>0
        - P: distribution de probabilités
        - k: base du logarithme à utiliser, par défaut 2
        rend la valeur de l'entropie de Shannon correspondante
    """
    
    res = 0
    
    for p in P:
        if p > 0:
            res += p * (np.log(p) / np.log(k))
    
    return res * (-1)
    
##################################################################

def entropie(Y, k=2):
    """ Y : (array) : ensemble de labels de classe
        Hypothèse: k>0
        - k: base du logarithme à utiliser, par défaut 2
        rend l'entropie de l'ensemble Y
    """
    
    P = []
    
    l_unique = np.unique(Y)
    len_Y = len(Y)
    
    for l in l_unique:
        taille = len(Y[Y == l])
        P.append(taille / len_Y)
        
    return shannon(P,k)

#############################################################################
    
def construit_AD(X,Y,epsilon,LNoms = [], verbose=False):
    """ X,Y : dataset
        epsilon : seuil d'entropie pour le critère d'arrêt 
        LNoms : liste des noms de features (colonnes) de description 
    """
    
    entropie_ens = entropie(Y)
    
    if verbose:
        print(f"Construction: entropie classe {entropie_ens:1.5f}")
        
    if (entropie_ens <= epsilon):
        # ARRET : on crée une feuille
        noeud = NoeudCategoriel(-1,"Label")
        noeud.ajoute_feuille(classe_majoritaire(Y))
        if verbose:
            print("\tajout d'une feuille avec la classe {classe_majoritaire(Y)}")
    else:
        min_entropie = 1.1
        i_best = -1
        Xbest_valeurs = None
        
        #############
        
        # COMPLETER CETTE PARTIE : ELLE DOIT PERMETTRE D'OBTENIR DANS
        # i_best : le numéro de l'attribut qui minimise l'entropie
        # min_entropie : la valeur de l'entropie minimale
        # Xbest_valeurs : la liste des valeurs que peut prendre l'attribut i_best
        #
        # Il est donc nécessaire ici de parcourir tous les attributs et de calculer
        # la valeur de l'entropie de la classe pour chaque attribut.
        
        
         
        #############################################
        for i in range(X.shape[1]):  # pour chaque attribut
    
            valeurs = np.unique(X[:, i])
    
            entropie_i = 0
    
            for v in valeurs:
        
                # sous-ensemble
                Yv = Y[X[:, i] == v]
        
                # poids
                p = len(Yv) / len(Y)
        
                # entropie pondérée
                entropie_i += p * entropie(Yv)
    
            # garder le meilleur attribut
            if entropie_i < min_entropie:
                min_entropie = entropie_i
                i_best = i
                Xbest_valeurs = valeurs
        
        
        if verbose:
            nom = str(i_best)
            if LNoms != []:
                nom = LNoms[i_best]
            print(f"\tMeilleur: {nom}: entropie= {min_entropie:1.5f}")
        if len(LNoms)>0:  # si on a des noms de features
            noeud = NoeudCategoriel(i_best,LNoms[i_best])    
        else:
            noeud = NoeudCategoriel(i_best)
        for v in Xbest_valeurs:
            if verbose:
                print(f"\tdescente pour {v}")
            noeud.ajoute_fils(v,construit_AD(X[X[:,i_best]==v], Y[X[:,i_best]==v],epsilon,LNoms,verbose))
    return noeud

####################################################################################

class NoeudCategoriel:
    """ Classe pour représenter des noeuds d'un arbre de décision
    """
    def __init__(self, num_att=-1, nom=''):
        """ Constructeur: il prend en argument
            - num_att (int) : le numéro de l'attribut auquel il se rapporte: de 0 à ...
              si le noeud se rapporte à la classe, le numéro est -1, on n'a pas besoin
              de le préciser
            - nom (str) : une chaîne de caractères donnant le nom de l'attribut si
              il est connu (sinon, on ne met rien et le nom sera donné de façon 
              générique: "att_Numéro")
        """
        
        self.__attribut = num_att    # numéro de l'attribut
        
        if (nom == ''):            # son nom si connu
            self.__nom_attribut = 'att_'+str(num_att)
        else:
            self.__nom_attribut = nom 
            
        self.__Les_fils = None       # aucun fils à la création, ils seront ajoutés
        
        self.__classe   = None       # valeur de la classe si c'est une feuille
        
    def est_feuille(self):
        """ rend True si l'arbre est une feuille 
            c'est une feuille s'il n'a aucun fils
        """
        
        return self.__Les_fils == None
    
    def ajoute_fils(self, valeur, Fils):
        """ valeur : valeur de l'attribut de ce noeud qui doit être associée à Fils
                     le type de cette valeur dépend de la base
            Fils (NoeudCategoriel) : un nouveau fils pour ce noeud
            Les fils sont stockés sous la forme d'un dictionnaire:
            Dictionnaire {valeur_attribut : NoeudCategoriel}
        """
        
        if self.__Les_fils == None:
            self.__Les_fils = dict()
            
        self.__Les_fils[valeur] = Fils
        # Rem: attention, on ne fait aucun contrôle, la nouvelle association peut
        # écraser une association existante.
    
    def ajoute_feuille(self,classe):
        """ classe: valeur de la classe
            Ce noeud devient un noeud feuille
        """
        
        self.__classe    = classe
        
        self.__Les_fils  = None   # normalement, pas obligatoire ici, c'est pour être sûr
        
    def classifie(self, exemple):
        """ exemple : numpy.array
            rend la classe de l'exemple 
            on rend la valeur None si l'exemple ne peut pas être classé (cf. les questions
            posées en fin de ce notebook)
        """
        
        if self.est_feuille():
            return self.__classe
        
        if exemple[self.__attribut] in self.__Les_fils:
            # descente récursive dans le noeud associé à la valeur de l'attribut
            # pour cet exemple:
            
            return self.__Les_fils[exemple[self.__attribut]].classifie(exemple)
        
        else:
            # Cas particulier : on ne trouve pas la valeur de l'exemple dans la liste des
            # fils du noeud... Voir la fin de ce notebook pour essayer de résoudre ce mystère...
            print('\t*** Warning: attribut ',self.__nom_attribut,' -> Valeur inconnue: ',exemple[self.__attribut])
            return None
    
    def compte_feuilles(self):
        """ rend le nombre de feuilles sous ce noeud
        """
        if self.est_feuille():
            return 1
        
        total = 0
        
        for noeud in self.__Les_fils:
            total += self.__Les_fils[noeud].compte_feuilles()
            
        return total
     
    def to_graph(self, g, prefixe='A'):
        """ construit une représentation de l'arbre pour pouvoir l'afficher graphiquement
            Cette fonction ne nous intéressera pas plus que ça, elle ne sera donc pas expliquée            
        """
        
        if self.est_feuille():
            g.node(prefixe,str(self.__classe),shape='box')
            
        else:
            g.node(prefixe, self.__nom_attribut)
            i =0
            for (valeur, sous_arbre) in self.__Les_fils.items():
                sous_arbre.to_graph(g,prefixe+str(i))
                g.edge(prefixe,prefixe+str(i), str(valeur))
                i = i+1  
                
        return g
    
##################################################################################

class ClassifierArbreDecision(Classifier):
    """ Classe pour représenter un classifieur par arbre de décision
    """
    
    def __init__(self, input_dimension, epsilon, LNoms=[]):
        """ Constructeur
            Argument:
                - intput_dimension (int) : dimension de la description des exemples
                - epsilon (float) : paramètre de l'algorithme (cf. explications précédentes)
                - LNoms : Liste des noms de dimensions (si connues)
            Hypothèse : input_dimension > 0
        """
        super().__init__(input_dimension)  # Appel du constructeur de la classe mère
        self.__epsilon = epsilon
        self.__LNoms = LNoms
        # l'arbre est manipulé par sa racine qui sera un Noeud
        self.__racine = None
        
    def __str__(self):
        """  -> str
            rend une chaîne de caractères (méthode toString) avec le nom du classifieur avec ses paramètres
        """
        return  super().__str__()+' - ArbreDecision ['+str(super().get_dimension()) + '] eps='+str(self.__epsilon)
        
    def train(self, desc_set, label_set,verbose=False):
        """ Permet d'entrainer le modele sur l'ensemble donné
            desc_set: ndarray avec des descriptions
            label_set: ndarray avec les labels correspondants
            Hypothèse: desc_set et label_set ont le même nombre de lignes
        """        
        
        self.__racine = construit_AD(desc_set, label_set, self.__epsilon, self.__LNoms, verbose)
    
    def score(self,x):
        """ rend le score de prédiction sur x (valeur réelle)
            x: une description
        """
        # cette méthode ne fait rien dans notre implémentation :
        pass
    
    def predict(self, x):
        """ x (array): une description d'exemple
            rend la prediction sur x             
        """

        return self.__racine.classifie(x)


    def accuracy(self, desc_set, label_set):
        """ Permet de calculer la qualité du système sur un dataset donné
            desc_set: ndarray avec des descriptions
            label_set: ndarray avec les labels correspondants
            Hypothèse: desc_set et label_set ont le même nombre de lignes
        """
        
        correct = 0
    
        for i in range(len(desc_set)):
        
            pred = self.predict(desc_set[i])
        
            if pred == label_set[i]:
                correct += 1
    
        return correct / len(desc_set)

    
    def number_leaves(self):
        """ rend le nombre de feuilles de l'arbre
        """
        return self.__racine.compte_feuilles()
    
    def draw(self,GTree):
        """ affichage de l'arbre sous forme graphique
            Cette fonction modifie GTree par effet de bord
        """
        self.__racine.to_graph(GTree)

#######################################################################################



##################################################################

def discretise(m_desc, m_class, num_col, verbose=False):
    """ Discrétisation : cherche le meilleur seuil de coupure pour la colonne num_col.
        Retour: ((seuil_trouve, entropie), (liste_coupures, liste_entropies))
        Si moins de 2 valeurs uniques: ((None, +Inf), ([], []))

        Implémentation VECTORISÉE (numpy) — comportement identique à la version
        naïve mais beaucoup plus rapide grâce au cumul des comptes par classe.
    """
    col = m_desc[:, num_col]
    l_valeurs = np.unique(col)
    if len(l_valeurs) < 2:
        return ((None, float('Inf')), ([], []))

    n = len(col)
    classes, idx_class = np.unique(m_class, return_inverse=True)
    nc = len(classes)

    order = np.argsort(col, kind='stable')
    sorted_col = col[order]
    sorted_idx = idx_class[order]

    one_hot = np.zeros((n, nc), dtype=np.int64)
    one_hot[np.arange(n), sorted_idx] = 1
    cum = np.cumsum(one_hot, axis=0)
    total = cum[-1]

    n_inf = np.arange(1, n + 1, dtype=np.float64)
    counts_inf = cum
    counts_sup = total - counts_inf
    n_sup = n - n_inf

    with np.errstate(divide='ignore', invalid='ignore'):
        p_inf = counts_inf / n_inf[:, None]
        p_sup = np.where(n_sup[:, None] > 0,
                         counts_sup / np.maximum(n_sup[:, None], 1),
                         0.0)
        log_inf = np.where(p_inf > 0, np.log2(np.maximum(p_inf, 1e-300)), 0.0)
        log_sup = np.where(p_sup > 0, np.log2(np.maximum(p_sup, 1e-300)), 0.0)
        ent_inf = -np.sum(p_inf * log_inf, axis=1)
        ent_sup = -np.sum(p_sup * log_sup, axis=1)
    weighted = (n_inf / n) * ent_inf + (n_sup / n) * ent_sup

    valid_pos = np.where(sorted_col[:-1] < sorted_col[1:])[0]
    cuts_v = sorted_col[valid_pos]
    cuts_e = weighted[valid_pos]

    if len(cuts_v) == 0:
        return ((None, float('Inf')), ([], []))

    if verbose:
        for v, e in zip(cuts_v, cuts_e):
            print(f"Discretise: coupure en {v} -> entropie de {e:1.4f}")

    best_idx = int(np.argmin(cuts_e))
    best_seuil = float(cuts_v[best_idx])
    best_entropie = float(cuts_e[best_idx])

    if verbose:
        print(f"Discretise: *** meilleure coupure en {best_seuil} "
              f"avec une entropie de {best_entropie:1.4f} ***")
    return (best_seuil, best_entropie), (cuts_v.tolist(), cuts_e.tolist())


###############################################################################################################

def partitionne(m_desc,m_class,n,s):
    """ input:
            - m_desc : (np.array) matrice des descriptions toutes numériques
            - m_class : (np.array) matrice des classes (correspondant à m_desc)
            - n : (int) numéro de colonne de m_desc
            - s : (float) seuil pour le critère d'arrêt
        Hypothèse: m_desc peut être partitionné ! (il contient au moins 2 valeurs différentes)
        output: un tuple composé de 2 tuples
    """
    return ((m_desc[m_desc[:,n]<=s], m_class[m_desc[:,n]<=s]), \
            (m_desc[m_desc[:,n]>s], m_class[m_desc[:,n]>s]))

################################################################################################## 

class NoeudNumerique:
    """ Classe pour représenter des noeuds numériques d'un arbre de décision
    """
    def __init__(self, num_att=-1, nom=''):
        """ Constructeur: il prend en argument
            - num_att (int) : le numéro de l'attribut auquel il se rapporte: de 0 à ...
              si le noeud se rapporte à la classe, le numéro est -1, on n'a pas besoin
              de le préciser
            - nom (str) : une chaîne de caractères donnant le nom de l'attribut si
              il est connu (sinon, on ne met rien et le nom sera donné de façon 
              générique: "att_Numéro")
        """
        
        self.__attribut = num_att    # numéro de l'attribut
        
        if (nom == ''):            # son nom si connu
            self.__nom_attribut = 'att_'+str(num_att)
            
        else:
            self.__nom_attribut = nom 
            
        self.__seuil = None          # seuil de coupure pour ce noeud
        self.__Les_fils = None       # aucun fils à la création, ils seront ajoutés
        self.__classe   = None       # valeur de la classe si c'est une feuille
        
    def est_feuille(self):
        """ rend True si l'arbre est une feuille 
            c'est une feuille s'il n'a aucun fils
        """
        
        return self.__Les_fils == None
    
    def ajoute_fils(self, val_seuil, fils_inf, fils_sup):
        """ val_seuil : valeur du seuil de coupure
            fils_inf : fils à atteindre pour les valeurs inférieures ou égales à seuil
            fils_sup : fils à atteindre pour les valeurs supérieures à seuil
        """
        
        if self.__Les_fils == None:
            self.__Les_fils = dict()    
            
        self.__seuil = val_seuil
        self.__Les_fils['inf'] = fils_inf
        self.__Les_fils['sup'] = fils_sup        
    
    def ajoute_feuille(self,classe):
        """ classe: valeur de la classe
            Ce noeud devient un noeud feuille
        """
        
        self.__classe    = classe
        self.__Les_fils  = None   # normalement, pas obligatoire ici, c'est pour être sûr
        
    def classifie(self, exemple):
        """ exemple : numpy.array
            rend la classe de l'exemple (pour nous, soit +1, soit -1 en général)
            on rend la valeur 0 si l'exemple ne peut pas être classé (cf. les questions
            posées en fin de ce notebook)
        """
        
        if self.est_feuille():    #si une feuille on a la classe
            return self.__classe
    
        val = exemple[self.__attribut]   #exemple c est un exemple de dataset apres on prend la valeur de la variable situee a self.attribut dans cet exemple
        #parcourir l'arbre selon cette val pour trouver la classe si elle existe
        if val <= self.__seuil:
            return self.__Les_fils['inf'].classifie(exemple)
        
        else:
            return self.__Les_fils['sup'].classifie(exemple)

    
    def compte_feuilles(self):
        """ rend le nombre de feuilles sous ce noeud
        """
        
        if self.est_feuille():
            return 1
    
        return self.__Les_fils['inf'].compte_feuilles() + self.__Les_fils['sup'].compte_feuilles()
     
    def to_graph(self, g, prefixe='A'):
        """ construit une représentation de l'arbre pour pouvoir l'afficher graphiquement
            Cette fonction ne nous intéressera pas plus que ça, elle ne sera donc 
            pas expliquée            
        """
        
        if self.est_feuille():
            g.node(prefixe,str(self.__classe),shape='box')
            
        else:
            g.node(prefixe, str(self.__nom_attribut))
            self.__Les_fils['inf'].to_graph(g,prefixe+"g")
            self.__Les_fils['sup'].to_graph(g,prefixe+"d")
            g.edge(prefixe,prefixe+"g", '<='+ str(self.__seuil))
            g.edge(prefixe,prefixe+"d", '>'+ str(self.__seuil))  
            
        return g
    
###################################################################################################

def construit_AD_num(X,Y,epsilon,LNoms = [], verbose=False):
    """ X,Y : dataset
        epsilon : seuil d'entropie pour le critère d'arrêt 
        LNoms : liste des noms de features (colonnes) de description 
        verbose: pour afficher des messages de débuggage
    """
    
    # dimensions de X:
    (nb_lig, nb_col) = X.shape
    
    entropie_classe = entropie(Y)
    
    if (entropie_classe <= epsilon) or  (nb_lig <=1):
        # ARRET : on crée une feuille
        noeud = NoeudNumerique(-1,"Label")  # On met la feuille dans un noeud catégoriel
        classe_choisie = classe_majoritaire(Y)
        noeud.ajoute_feuille(classe_choisie)
        if verbose:
            print("AD: construction d'une feuille avec {classe_choisie}")
    else:
        gain_max = 0.0  # meilleur gain trouvé (initalisé à 0.0 => aucun gain)
        i_best = -1     # numéro du meilleur attribut (init à -1 (aucun))
        
        #############
        
        # COMPLETER CETTE PARTIE : ELLE DOIT PERMETTRE D'OBTENIR DANS
        # i_best : le numéro de l'attribut qui maximise le gain d'information.  En cas d'égalité,
        #          le premier rencontré est choisi.
        # gain_max : la plus grande valeur de gain d'information trouvée.
        # Xbest_tuple : le tuple rendu par partionne() pour le meilleur attribut trouvé
        # Xbest_seuil : le seuil de partitionnement associé au meilleur attribut
        #
        # Remarque : attention, la fonction discretise() peut renvoyer un tuple contenant
        # None (pas de partitionnement possible)n dans ce cas, on considèrera que le
        # résultat d'un partitionnement est alors ((X,Y),(None,None))
        
        ############
        for i in range(nb_col):

            # meilleur seuil pour la colonne i
            (best_seuil, best_entropie), _ = discretise(X, Y, i)

            # si aucun seuil possible
            if best_seuil is None:
                continue

            # calcul du gain d'information
            gain = entropie_classe - best_entropie

            # si meilleur gain trouvé
            if gain > gain_max:

                gain_max = gain
                i_best = i
                Xbest_seuil = best_seuil

                # partition des données avec ce seuil
                Xbest_tuple = partitionne(X, Y, i, best_seuil)

                if verbose:
                    print("Meilleur attribut :", i)
                    print("Seuil :", best_seuil)
                    print("Gain :", gain)
        
        if (i_best != -1): # Un attribut qui amène un gain d'information >0 a été trouvé
            if len(LNoms)>0:  # si on a des noms de features
                noeud = NoeudNumerique(i_best,LNoms[i_best]) 
            else:
                noeud = NoeudNumerique(i_best)
            ((left_data,left_class), (right_data,right_class)) = Xbest_tuple
            noeud.ajoute_fils( Xbest_seuil, \
                              construit_AD_num(left_data,left_class, epsilon, LNoms), \
                              construit_AD_num(right_data,right_class, epsilon, LNoms) )
        else: # aucun attribut n'a pu améliorer le gain d'information
              # ARRET : on crée une feuille
            noeud = NoeudNumerique(-1,"Label")
            noeud.ajoute_feuille(classe_majoritaire(Y))
        
    return noeud

######################################################################################################

class ClassifierArbreNumerique(Classifier):
    """ Classe pour représenter un classifieur par arbre de décision numérique
    """
    
    def __init__(self, input_dimension, epsilon, LNoms=[]):
        """ Constructeur
            Argument:
                - intput_dimension (int) : dimension de la description des exemples
                - epsilon (float) : paramètre de l'algorithme (cf. explications précédentes)
                - LNoms : Liste des noms de dimensions (si connues)
            Hypothèse : input_dimension > 0
        """
        super().__init__(input_dimension)  # Appel du constructeur de la classe mère
        self.__epsilon = epsilon
        self.__LNoms = LNoms
        # l'arbre est manipulé par sa racine qui sera un Noeud
        self.__racine = None
        
    def __str__(self):
        """  -> str
            rend le nom du classifieur avec ses paramètres
        """
        return  super().__str__()+' - ArbreNumerique ['+str(super().get_dimension()) + '] eps='+str(self.__epsilon)
        
    def train(self, desc_set, label_set,verbose=False):
        """ Permet d'entrainer le modele sur l'ensemble donné
            desc_set: ndarray avec des descriptions
            label_set: ndarray avec les labels correspondants
            verbose: pour afficher des messages de débuggage
            Hypothèse: desc_set et label_set ont le même nombre de lignes
        """        
        self.__racine = construit_AD_num(desc_set, label_set, self.__epsilon, self.__LNoms, verbose)
   
    def score(self,x):
        """ rend le score de prédiction sur x (valeur réelle)
            x: une description
        """
        # cette méthode ne fait rien dans notre implémentation :
        pass
    
    def predict(self, x):
        """ x (array): une description d'exemple
            rend la prediction sur x             
        """
        return self.__racine.classifie(x)

    def accuracy(self, desc_set, label_set):  # Version propre à aux arbres
        """ Permet de calculer la qualité du système sur un dataset donné
            desc_set: ndarray avec des descriptions
            label_set: ndarray avec les labels correspondants
            Hypothèse: desc_set et label_set ont le même nombre de lignes
        """
        nb_bons = 0

        for i in range(len(desc_set)):

            prediction = self.predict(desc_set[i])

            if prediction == label_set[i]:
                nb_bons += 1

        return nb_bons / len(label_set)

    def number_leaves(self):
        """ rend le nombre de feuilles de l'arbre
        """
        return self.__racine.compte_feuilles()
    
    def affiche(self,GTree):
        """ affichage de l'arbre sous forme graphique
            Cette fonction modifie GTree par effet de bord
        """
        self.__racine.to_graph(GTree)

###########################################################################################################

def construit_AD_gen(X,Y,epsilon, LNoms, LTypes,verbose=False):
    """ X,Y : dataset
        epsilon : seuil d'entropie pour le critère d'arrêt 
        LNoms : liste des noms de features (colonnes) de description 
        LTypes: liste de booléens qui donne le type des features :
                LTypes[i] est True si LNoms[i] est un attribut numérique
                LTypes[i] est False si LNoms[i] est un attribut symbolique
        verbose: pour afficher des messages de débuggage
        Hypothèse: len(LTypes) >0 et len(LNoms]>0
    """
    
    # dimensions de X:
    (nb_lig, nb_col) = X.shape
    entropie_classe = entropie(Y)
    
    if (entropie_classe <= epsilon) or  (nb_lig <=1):
        # ARRET : on crée une feuille
        noeud = NoeudNumerique(-1,"Label")
        if len(Y) <1:
            noeud.ajoute_feuille(None)    
        else:
            noeud.ajoute_feuille(classe_majoritaire(Y))
    else:
        LCols_num = [i for i in range(0,len(LTypes)) if LTypes[i]]
        if len(LCols_num) == 0: # Pas d'attributs numériques
            return construit_AD(X,Y,epsilon,LNoms)
            
        LCols_cat = [i for i in range(0,len(LTypes)) if not(LTypes[i])]
        if len(LCols_cat) == 0: # Pas d'attributs catégoriels
            return construit_AD_num(X,Y,epsilon,LNoms,verbose)

        gain_max = 0.0  # meilleur gain trouvé (initalisé à 0.0 => aucun gain)
        i_best = -1     # numéro du meilleur attribut (init à -1 (aucun))        
        #############
        for i in range(0,X.shape[1]):
            if LTypes[i]:  # attribut numérique
                (best_seuil, best_entropie), _ = discretise(X, Y, i)
                entropie_Xi = best_entropie
                gain = entropie_classe - entropie_Xi
                if gain > gain_max:
                    gain_max = gain
                    i_best = i
                    Xbest_seuil = best_seuil
                    
            else: # attribut catégoriel
                valeurs = np.unique(X[:,i])
                entropie_Xi = 0.0
                for v in valeurs:
                    sous_ens = Y[X[:,i] == v]
                    entropie_Xi += (len(sous_ens)/len(Y)) * entropie(sous_ens)
                gain = entropie_classe - entropie_Xi
                if gain > gain_max:
                    gain_max = gain
                    i_best = i

            if verbose:
                nom = str(i)
                if LNoms != []:
                    nom = LNoms[i]
                print(f"\tattribut {nom}: entropie= {entropie_Xi:1.5f}")

        ############
        if (i_best != -1): # Un attribut qui amène un gain d'information >0 a été trouvé
            if LTypes[i_best]:
                noeud = NoeudNumerique(i_best, LNoms[i_best])
                ((left_data,left_class),(right_data,right_class)) = partitionne(X,Y,i_best,Xbest_seuil)
                noeud.ajoute_fils(Xbest_seuil, construit_AD_gen(left_data,left_class,epsilon,LNoms,LTypes),
                    construit_AD_gen(right_data,right_class,epsilon,LNoms,LTypes))
                
            else:
                noeud = NoeudCategoriel(i_best, LNoms[i_best])
                valeurs = np.unique(X[:,i_best])
                for v in valeurs:
                    desc_v = X[X[:,i_best] == v]
                    label_v = Y[X[:,i_best] == v]
                    noeud.ajoute_fils(v, construit_AD_gen(desc_v,label_v,epsilon,LNoms,LTypes))

        ###########################################################        
        else: # aucun attribut n'a pu améliorer le gain d'information
              # ARRET : on crée une feuille
            noeud = NoeudCategoriel(-1,"Label")
            noeud.ajoute_feuille(classe_majoritaire(Y))
        
    return noeud

############################################################################################################################

class ClassifierArbreGeneral(Classifier):
    """ Classe pour représenter un classifieur par arbre de décision (numérique ou catégoriel)
    """
    
    def __init__(self, input_dimension, epsilon, LNoms=[], LTypes=[]):
        """ Constructeur
            Argument:
                - intput_dimension (int) : dimension de la description des exemples
                - epsilon (float) : paramètre de l'algorithme (cf. explications précédentes)
                - LNoms : Liste des noms de dimensions (si connues)
            LTypes: liste de booléens qui donne le type des features :
                LTypes[i] est True si LNoms[i] est un attribut numérique
                LTypes[i] est False si LNoms[i] est un attribut symbolique
                si la liste est vide, on considère que tous les attributs 
                sont numériques (comme si la liste ne contenait que des True)
            Hypothèses : 
                - input_dimension > 0
                - si len(LTypes) vaut soit 0 (vide), soit input_dimension
                - si len(Noms) vaut soit 0 (vide), soit input_dimension
            
        """
        super().__init__(input_dimension)  # Appel du constructeur de la classe mère
        self.__dimension = input_dimension
        self.__epsilon = epsilon
        
        if len(LNoms) == 0:
            self.__LNoms = ['att_'+str(i) for i in range(0,input_dimension)]
        else:
            self.__LNoms = LNoms
            
        if len(LTypes) == 0:
            self.__LTypes = [True for i in range(input_dimension)]
        else:
            self.__LTypes = LTypes        
        self.__racine = None
        
    def __str__(self):
        """  -> str
            rend le nom du classifieur avec ses paramètres
        """
        return  super().__str__()+' - ArbreGeneral ['+str(super().get_dimension()) + '] eps='+str(self.__epsilon)
        
    def train(self, desc_set, label_set,verbose=False):
        """ Permet d'entrainer le modele sur l'ensemble donné
            desc_set: ndarray avec des descriptions
            label_set: ndarray avec les labels correspondants
            verbose: pour afficher des messages de débuggage
            Hypothèse: desc_set et label_set ont le même nombre de lignes
        """        
        self.__racine = construit_AD_gen(desc_set, label_set, self.__epsilon, self.__LNoms, self.__LTypes,verbose)
   
    def score(self,x):
        """ rend le score de prédiction sur x (valeur réelle)
            x: une description
        """
        # cette méthode ne fait rien dans notre implémentation :
        pass
    
    def predict(self, x):
        """ x (array): une description d'exemple
            rend la prediction sur x             
        """
        return self.__racine.classifie(x)

    def accuracy(self, desc_set, label_set):  # Version propre à aux arbres
        """ Permet de calculer la qualité du système sur un dataset donné
            desc_set: ndarray avec des descriptions
            label_set: ndarray avec les labels correspondants
            Hypothèse: desc_set et label_set ont le même nombre de lignes
        """
        nb_bons = 0
        for i in range(len(desc_set)):
            prediction = self.predict(desc_set[i])
            if prediction == label_set[i]:
                nb_bons += 1
        return nb_bons / len(label_set)

    def number_leaves(self):
        """ rend le nombre de feuilles de l'arbre
        """
        return self.__racine.compte_feuilles()
    
    def affiche(self,GTree):
        """ affichage de l'arbre sous forme graphique
            Cette fonction modifie GTree par effet de bord
        """
        self.__racine.to_graph(GTree)

######################################################################################################################################

class ClassifierKNN_MC(Classifier):
    """KNN multi-classes (vote majoritaire parmi les k voisins)."""
    def __init__(self, input_dimension, k, nc):
        super().__init__(input_dimension)
        self.k = k
        self.nc = nc
        self.desc_set = None
        self.labels_set = None

    def train(self, desc_set, label_set):
        self.desc_set = desc_set
        self.labels_set = label_set

    def score(self, x):
        d = np.linalg.norm(self.desc_set - x, axis=1)
        kn = self.labels_set[np.argsort(d)[:self.k]]
        counts = np.zeros(self.nc, dtype=int)
        for lab in kn:
            counts[int(lab)] += 1
        return counts

    def predict(self, x):
        return int(np.argmax(self.score(x)))

######################################################################################################################################

class ClassifierBaggingArbre(Classifier):
    """Bagging d'arbres : agrège B arbres par vote majoritaire."""
    def __init__(self, B, percentage, epsilon, remise=True):
        super().__init__(0)
        self.B = B
        self.pct = percentage
        self.epsilon = epsilon
        self.remise = remise
        self.arbres = []

    def train(self, desc_set, label_set):
        n = len(desc_set)
        n_sample = max(1, int(self.pct * n))
        d = desc_set.shape[1]
        self.arbres = []
        for _ in range(self.B):
            idx = np.random.choice(n, size=n_sample, replace=self.remise)
            arbre = ClassifierArbreNumerique(d, self.epsilon)
            arbre.train(desc_set[idx], label_set[idx])
            self.arbres.append(arbre)

    def score(self, x):
        votes = [a.predict(x) for a in self.arbres]
        v, c = np.unique(votes, return_counts=True)
        return float(c.max() / len(votes))

    def predict(self, x):
        votes = [a.predict(x) for a in self.arbres]
        v, c = np.unique(votes, return_counts=True)
        return v[int(np.argmax(c))]

    def accuracy(self, desc_set, label_set):
        n = len(label_set)
        return sum(1 for i in range(n) if self.predict(desc_set[i]) == label_set[i]) / n

######################################################################################################################################
