# -*- coding: utf-8 -*-

"""
Package: iads
File: Clustering.py
Année: LU3IN026 - semestre 2 - 2025-2026, Sorbonne Université
"""

# -----------------------------------------------------------------------
# Fonctions de Clustering

# import externe
import numpy as np
import pandas as pd
from abc import ABC, abstractmethod
import scipy.cluster.hierarchy
import matplotlib.pyplot as plt
import matplotlib as mtpl
import matplotlib.cm as cm
import math
import time
import sys
# -----------------------------------------------------------------------
def normalisation(df):
    
    df_norm = df.copy()
    
    for col in df.columns:
        
        min_col = df[col].min()
        max_col = df[col].max()
        
        df_norm[col] = (df[col] - min_col) / (max_col - min_col)
    
    return df_norm
# -----------------------------------------------------------------------
class Distance(ABC):
    """ Classe abstraite pour représenter des mesures de distances
        Elle permet de définir une hiérarchie pour les distances
    """
    def __init__(self,nom):
        """ Constructeur:
            prend en argument le nom (str) de la distance créé
        """
        self.__nom:str = nom
        
    @abstractmethod
    def calcule(self, v, M):
        """ Arguments:
                - v: un vecteur 
                - M: un vecteur ou une matrice 
            Hypothèse: v et M ont le même nombre de colonnes
            Retour:
                - un float si M est une vecteur: distance entre v et M
                - une np.series si M est une matrice: distances entre le vecteur v et chaque vecteur de M
        """
        # le calcul de distance dépend de la mesure que l'on utilise, il sera implémenté
        # dans les sous-classes de cette classe.
        pass
        
    def __str__(self) -> str:
        """ rend une chaîne de caractères (méthode toString)
            Par exemple, pour afficher des informations sur l'objet
        """
        return "Distance "+self.__nom
# -----------------------------------------------------------------------
class DistanceEuclidienne(Distance):
    """ Classe représentant la distance euclidienne
    """
    def __init__(self):
        """ Constructeur
        """
        super().__init__("euclidienne")
        
    def calcule(self, v, M):
        """ Arguments:
                - v: un vecteur 
                - M: un vecteur ou une matrice
            Hypothèse: v et M ont le même nombre de colonnes
            Retour:
                - un float si M est une vecteur: distance entre v et M
                - une np.series si M est une matrice: distances entre le vecteur v et chaque vecteur de M
        """
        if v.ndim != 1:
            raise TypeError("Argument incorrect: le premier argument doit être un vecteur")

        if M.ndim == 1:   # si M est un vecteur
            return np.linalg.norm(v - M)  

        return np.linalg.norm(M - v, axis=1)    # sinon M une matrice, donc calculer la norme ligne par ligne
        
 
    def __str__(self) -> str:
        """ rend une chaîne de caractères (méthode toString)
            Par exemple, pour afficher des informations sur l'objet
        """
        return super().__str__()    
# --------------------------------------------------------------------------
class Linkage(ABC):
    """ Classe abstraite pour représenter des approches Linkage
    """
    def __init__(self,nom):
        """ Constructeur:
            prend en argument:
                - nom (str) du linkage
        """
        self.__nom: str = nom
        
    @abstractmethod
    def calcule(self, G1, G2, verbose= False):
        """ Arguments:
                - G1 et G2 sont des dataframes ou des np.array
                - verbose: pour afficher des messages de débuggage si besoin
            Hypothèse: 
                - G1 et G2 ont le même nombre de colonnes
            Retour:
                - la distance entre G1 et G2 selon le linkage
        """
        pass
        
    def __str__(self) -> str:
        """ rend une chaîne de caractères (méthode toString)
            Par exemple, pour afficher des informations sur l'objet
        """
        return "Linkage "+self.__nom
# -----------------------------------------------------------------------
class LinkageComplete(Linkage):
    """ Classe pour le linkage "Complete"
    """
    def __init__(self,distance=DistanceEuclidienne()):
        """ Constructeur:
            prend en argument:
                - nom (str) du linkage
                - distance (Distance): mesure de distance entre 2 exemples
                  par défaut: distance euclidienne
        """
        super().__init__("complete")
        self.__distance = distance
        
    def calcule(self, G1, G2,verbose=False):
        """ Arguments:
                - G1 et G2 sont des dataframes ou des np.array
                - verbose: pour afficher des messages de débuggage si besoin
            Hypothèse: 
                - G1 et G2 ont le même nombre de colonnes
            Retour:
                - la distance entre G1 et G2 selon le linkage
        """
        
        # on veut la distance maximale entre deux points un de G1 et l autre de G2 et c est celle ci la distance entre G1 et G2
        distances = []
        # pour que les valeur seront dans des matrices et pouvoir les utilisees dans la boucle
        # car si le un grp est un vecteur et non pas df (matrice) alors la boucle prendra les val de ce vect
        G1_vals = np.atleast_2d(G1)
        G2_vals = np.atleast_2d(G2)

        for x in G1_vals:
            for y in G2_vals:
                d = self.__distance.calcule(x, y)
                distances.append(d)

        if verbose:
            print(distances)

        return max(distances)
        
    def __str__(self) -> str:
        """ rend une chaîne de caractères (méthode toString)
            Par exemple, pour afficher des informations sur l'objet
        """
        return super().__str__()+ " ("+self.__distance.__str__()+")"
# ------------------------------------------------------------------------
class LinkageSimple(Linkage):
    """ Classe pour le linkage "Simple"
    """
    def __init__(self,distance=DistanceEuclidienne()):
        """ Constructeur:
            prend en argument:
                - nom (str) du linkage
                - distance (Distance): mesure de distance entre 2 exemples
                  par défaut: distance euclidienne
        """
        super().__init__("simple")
        self.__distance = distance

    def calcule(self, G1, G2, verbose=False):

        distances = []

        G1_vals = np.atleast_2d(G1)
        G2_vals = np.atleast_2d(G2)

        for x in G1_vals:
            for y in G2_vals:
                d = self.__distance.calcule(x,y)
                distances.append(d)

        if verbose:
            print(distances)

        return min(distances)
        
    def __str__(self) -> str:
        """ rend une chaîne de caractères (méthode toString)
            Par exemple, pour afficher des informations sur l'objet
        """
        return super().__str__()+ " ("+self.__distance.__str__()+")"
# -----------------------------------------------------------------------
class LinkageAverage(Linkage):
    """ Classe pour le linkage "Average"
    """
    def __init__(self,distance=DistanceEuclidienne()):
        """ Constructeur:
            prend en argument:
                - nom (str) du linkage
                - distance (Distance): mesure de distance entre 2 exemples
                  par défaut: distance euclidienne
        """
        super().__init__("average")     
        self.__distance = distance

    def calcule(self, G1, G2, verbose=False):

        distances = []

        G1_vals = np.atleast_2d(G1)
        G2_vals = np.atleast_2d(G2)

        for x in G1_vals:
            for y in G2_vals:
                d = self.__distance.calcule(x,y)
                distances.append(d)

        if verbose:
            print(distances)

        return np.mean(distances)

    def __str__(self) -> str:
        """ rend une chaîne de caractères (méthode toString)
            Par exemple, pour afficher des informations sur l'objet
        """
        return super().__str__()+ " ("+self.__distance.__str__()+")"
# -----------------------------------------------------------------------
class LinkageCentroide(Linkage):
    """ Classe pour le linkage "Centroide"
    """
    def __init__(self,distance=DistanceEuclidienne()):
        """ Constructeur:
            prend en argument:
                - nom (str) du linkage
                - distance (Distance): mesure de distance entre 2 exemples
                  par défaut: distance euclidienne
        """
        super().__init__("centroide")
        self.__distance = distance

    def calcule(self, G1, G2, verbose=False):

        distances = []

        G1_vals = np.atleast_2d(G1)
        G2_vals = np.atleast_2d(G2)

        centre1 = np.mean(G1_vals, axis=0)
        centre2 = np.mean(G2_vals, axis=0)

        if verbose:
            print("Centre G1 :", centre1)
            print("Centre G2 :", centre2)

        return self.__distance.calcule(centre1, centre2)

    def __str__(self) -> str:
        """ rend une chaîne de caractères (méthode toString)
            Par exemple, pour afficher des informations sur l'objet
        """
        return super().__str__()+ " ("+self.__distance.__str__()+")"
# -----------------------------------------------------------------------
# au debut chaque exemple est isolé dans son cluster
# donc le nb dexemples egal au nb de clusters
def CHA_initialise(DF):

    partition = {}

    for i in range(len(DF)):
        partition[i] = [i]

    return partition
# ------------------------------------------------------------------------
def CHA_fusionne(DF, P0, linkage, verbose=False):

    dist_min = float("inf")   # pour nous donner une valeur a l infini

    # les cles des deux clusters à fusionner
    cle1 = None   
    cle2 = None

    # trouver les clusters c1 et c2 les plus proches parmi tous les clusters de la partition P0
    for c1 in P0:
        for c2 in P0:
            if c1 < c2:    # evite de faire des calculs doubles
                # recuperer les exemples de chaque cluster
                G1 = DF.iloc[P0[c1]]   
                G2 = DF.iloc[P0[c2]]
                # calculer la dist entre ces deux clusters groupes)
                d = linkage.calcule(G1, G2)   
                # si on a trouve une dist min la sauvgarder
                if d < dist_min:
                    dist_min = d
                    cle1 = c1
                    cle2 = c2

    P1 = P0.copy()   # P1 est identique a P0, juste on fusionne c1 et c2 qui seront aussi supprimes apres le fusion

    # le nouveau cluster resultant du fusion de c1 et c2
    nouveau_cluster = P1[cle1] + P1[cle2]

    # la cle du cluster resultant du fusion de c1 et c2 : on obtient pour P1 une suite croissante de cles
    nouvelle_cle = max(P1.keys()) + 1

    # ajouter ce nouveau cluster a la partition
    P1[nouvelle_cle] = nouveau_cluster

    # supprimer les anciens clusters que on a fusionne
    del P1[cle1]
    del P1[cle2]

    if verbose:
        print("CHA_fusionne: distance minimale trouvée entre", P0[cle1], "et", P0[cle2], "=", dist_min)

    return P1, cle1, cle2, dist_min   # le tuple a retourne
# ------------------------------------------------------------------------
def CHA_algorithme(DF, linkage, verbose=False):

    P = CHA_initialise(DF)   # creer la partition de depart ou chaque exemple est dans son propre cluster

    resultats = []
    # CHA : arreter l algo quand il nous reste un seul cluster
    while len(P) > 1:   # tant que il nous reste des clusters a fusionner donc au min il en reste deux

        P1, cle1, cle2, dist = CHA_fusionne(DF, P, linkage, verbose)

        taille = len(P[cle1]) + len(P[cle2])      # des partitions donc elles sont disjointes

        resultats.append([cle1, cle2, dist, taille])   # y sauvegarder l ordre du fusion

        P = P1

    return resultats
# -----------------------------------------------------------------------
def CHA_dendrogramme(liste_resultat, linkage):
    
    plt.figure(figsize=(30,15))
    
    plt.title("Dendrogramme: " + str(linkage), fontsize=25)
    plt.xlabel("Indice d'exemple", fontsize=20)
    plt.ylabel("Distance", fontsize=20)
    
    scipy.cluster.hierarchy.dendrogram(
        liste_resultat,
        leaf_font_size=24
    )
    
    plt.show()
# ------------------------------------------------------------------------
class DistanceMinkowski(Distance):
    """ Classe représentant la distance de Minkowski """
    
    def __init__(self, p=2):
        
        super().__init__("minkowski")   # comme les autre distances juste elle un le parametre p en plus
        self.__p = p
        
        
    def calcule(self, v, M):
        
        if v.ndim != 1:
            raise TypeError("Le premier argument doit être un vecteur")
        
        
        # M un vecteur
        if M.ndim == 1:
            
            return np.sum(np.abs(v - M)**self.__p)**(1/self.__p)
        
        
        # sinon M une matrice ( un df)
        distances = []
        
        for ligne in M.values:
            
            d = np.sum(np.abs(v - ligne)**self.__p)**(1/self.__p)
            
            distances.append(d)
            
        return np.array(distances)
    
    
    def __str__(self):
        
        return "Distance Minkowski p=" + str(self.__p)
# -----------------------------------------------------------------------
class KMoyennes():
    """ Classe implémentant l'algorithme des K-moyennes
    """
    
    def __init__(self, K, distance=None ):
        """ Argument:
                - K (int) : nombre de clusters voulus
                - distance (Distance): mesure de distance entre 2 exemples
                  par défaut: distance euclidienne
        """
        # Distance par défaut : DistanceEuclidienne (de ce module).
        # On ne peut pas utiliser DistanceEuclidienne() en valeur par défaut
        # car la classe n'est pas encore définie au moment de l'évaluation.
        if distance is None:
            distance = DistanceEuclidienne()
        if K<1:
            raise TypeError("KMoyennes: K doit être strictement plus grand que 0 !")
        self.__K = K 
        self.__distance = distance    # pour le type de la distance utilise 

    def get_K(self):
        """ Accesseur de la variable __K
        """
        return self.__K

    def __str__(self) -> str:
        """ rend une chaîne de caractères (méthode toString)
            Par exemple, pour afficher des informations sur l'objet
        """
        return f"KMoyennes (K={self.__K}, {self.__distance})\n"

    def inertie_cluster(self, Ens):
        """ Arguments :
                - Ens: array qui représente un cluster
            Hypothèse: len(Ens)> >= 2
            L'inertie est la somme (au carré) des distances des points au centroide.
        """
        centre = np.mean(Ens, axis=0)       # calcul du centre de Ens

        inertie = 0
        # chaque exemple recupere du dataframe n est pas directement un array  (Ens.iloc[i])
        # donc il faut le transformer en np.array pour pouvoir utiliser calcule() (le v.ndim)
        for i in range(len(Ens)):   
            x = np.array(Ens.iloc[i])
            d = self.__distance.calcule(x, centre)
            inertie += d**2

        return inertie    # pour verifie si le clusters est bon, si ses points sont tous proches
                 
    def init(self,Ens):
        """ Argument :
                - Ens: Array contenant n exemples
                Choisir K centroides aleatoirement parmi les exemples, donc on va avoir K clusters
        """
        # replace=False : pour eviter de choisir deux indices egaux
        indices = np.random.choice(len(Ens), self.__K, replace=False)  # prendre K indices differents aleatoirement

        return np.array(Ens.iloc[indices])  # recuperer les exemples qui correspondent a ces indices


    def plus_proche(self, exemple, Centres):
        """ Arguments :
                - exemple : Array contenant un exemple
                - Centres : Array contenant les K centres
                Retourne l'indice du centre ck le plus proche de exemple, donc le centre avec la distance minimale a l'exemple
        """
        dist_min = float("inf")   # initialise avec une valeur a l infini
        indice_min = 0

        for i in range(len(Centres)):  # parcourir tous les centres

            d = self.__distance.calcule(exemple, Centres[i])

            if d < dist_min:
                dist_min = d
                indice_min = i

        return indice_min

    def affecte_cluster(self, Base, Centres):
        """ Arguments :
                - Base: Array contenant la base d'apprentissage
                - Centres : Array contenant des centroides
                affecter l'indice de chaque exemple au centre (l'indice du centre) le plus proche de lui
        """
        res = dict()    # associer chaque centre a la liste des exemples qui lui sont proches

        for i in range(len(Centres)):     # pour utiliser append sur res
            res[i] = []

        for i in range(len(Base)):

            x = np.array(Base.iloc[i])   # je recupere l exemple a la ligne i de Base

            proche = self.plus_proche(x, Centres)  # et je chercche le centre qui lui est plus proche

            res[proche].append(i)

        return res   
    
    def centroides(self, Base, U):
        """ Arguments :
                - Base : Array contenant la base d'apprentissage
                - U : Dictionnaire d'affectation
                Recalcule les nouveaux centres des clusters obtenus avec affecte_cluster
        """ 
        centres = []

        for k in U.keys():

            exemples = Base.iloc[U[k]]   # recuperer les exemples du cluster k

            centre = np.mean(exemples, axis=0)   # calculer le nouveau centre

            centres.append(centre)

        return np.array(centres)

    def inertie_globale(self,Base, U):
        """ Arguments :
                - Base : Array pour la base d'apprentissage
                - U : Dictionnaire d'affectation
                Retourne la somme de inerties de tous les clusters de la Base
        """        
        inertie = 0

        for k in U.keys():

            exemples = Base.iloc[U[k]]

            inertie += self.inertie_cluster(exemples)

        return inertie

    def train(self, Base, epsilon, iter_max, verbose=False):
        """ Arguments :
                - Base : Array pour la base d'apprentissage
                - epsilon : réel >0
                - iter_max : entier >1
                - verbose: pour afficher des messages de débuggage si besoin
                appliquer l algo de k-means sur la Base
                donc lui appliquer les fonctions en haut
        """       
        # choisir K centres aleatoirement
        Centres = self.init(Base)
        # affecter chaque exemple de Base au centre le plus proche de lui
        U = self.affecte_cluster(Base, Centres)

        inertie_prec = self.inertie_globale(Base, U)
        
        for i in range(iter_max):
            # calcul des nouveaux centres
            Centres = self.centroides(Base, U)
            # affecter chaque exemple de Base au nouveau centre le plus proche de lui
            U = self.affecte_cluster(Base, Centres)

            inertie = self.inertie_globale(Base, U)  # la nouvelle inertie

            diff = abs(inertie - inertie_prec)

            if verbose: 
                if i == 0:
                    print(f"\nEtapes de l'apprentissage (epsilon = {epsilon:.3f} et iter_max = {iter_max}) :")
                    print(f"\titeration n°{i+1}: Inertie = {inertie_prec:.4f}\tDifference = --")
                else:
                    print(f"\titeration n°{i+1}: Inertie = {inertie:.4f}\tDifference = {diff:.4f}")

            if diff < epsilon:  # si les clusters restent stables alors convergeance
                break

            inertie_prec = inertie

        return Centres, U
# --------------------------------------------------------------------------------------------------------------------------------
def affiche_resultat(Base, Centres, Affect):
    """ Arguments :
            - ensemble d'exemples
            - ensemble de centroides
            - matrice d'affectation, qui est un dictionnaire, qui associe a chaque numero de cluster 
            sa liste des indices des exemples qu'il contient         
    """
    couleurs = cm.tab20(np.linspace(0, 1, len(Affect)))
    print("Nombre de couleurs différentes", len(couleurs))  # donc nb couleurs = nb clusters
    
    for k, c in zip(Affect.keys(), couleurs):   # pour chaque cluster une couleur dans couleurs
        indices = Affect[k]

        X = Base.iloc[indices]["X1"]
        Y = Base.iloc[indices]["X2"]

        plt.scatter(X, Y, color=c)

    plt.scatter(Centres[:,0], Centres[:,1],
                color='r', marker='x', s=50)

    plt.show()
# ------------------------------------------------------------------------------------------------------------------------------------
def index_Dunn(Base, Centres, Affect):

    # distance minimale entre les centroïdes
    dist_min = float("inf")

    for i in range(len(Centres)):
        for j in range(i+1, len(Centres)):

            d = np.linalg.norm(Centres[i] - Centres[j])

            if d < dist_min:
                dist_min = d

    # diamètre maximal des clusters
    diam_max = 0

    for k in Affect.keys():

        indices = Affect[k]
        points = np.array(Base.iloc[indices])

        for i in range(len(points)):
            for j in range(i+1, len(points)):

                d = np.linalg.norm(points[i] - points[j])

                if d > diam_max:
                    diam_max = d

    return dist_min / diam_max
# -----------------------------------------------------------------------------------------------------------------------
def index_XieBeni(Base, Centres, Affect):

    n = len(Base)

    # somme des distances au carré aux centroïdes
    somme = 0

    for k in Affect.keys():

        indices = Affect[k]
        points = np.array(Base.iloc[indices])

        for x in points:

            somme += np.linalg.norm(x - Centres[k])**2

    # distance minimale entre centroïdes
    dist_min = float("inf")

    for i in range(len(Centres)):
        for j in range(i+1, len(Centres)):

            d = np.linalg.norm(Centres[i] - Centres[j])**2

            if d < dist_min:
                dist_min = d

    return somme / (n * dist_min)
# -------------------------------------------------------------------------------------------------------------------------------
