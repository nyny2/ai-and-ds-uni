# -*- coding: utf-8 -*-

"""
Package: iads
File: utils.py
Année: LU3IN026 - semestre 2 - 2025-2026, Sorbonne Université
"""


# Fonctions utiles
# Version de départ : Février 2026

# import externe
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import random

# ------------------------ 

def genere_dataset_uniform(d, nc, binf=-1, bsup=1):
    """ int * int * float^2 -> tuple[array, array]
        Hyp: n est pair
        d: nombre de dimensions de la description
        nc: nombre d'exemples de chaque classe
        les valeurs générées uniformément sont dans [binf,bsup]
    """
    
    data1_desc = np.vstack((np.random.uniform(binf, bsup, 2*nc),np.random.uniform(binf, bsup, 2*nc))).T

    data1_label = np.array([-1 for i in range(0,nc)] + [+1 for i in range(0,nc)])

    return data1_desc,data1_label
    
def genere_dataset_gaussian(positive_center, positive_sigma, negative_center, negative_sigma, nc):
    """ les valeurs générées suivent une loi normale
        rend un tuple (data_desc, data_labels)
    """
    pos=np.random.multivariate_normal(positive_center, positive_sigma, size=nc)
    neg=np.random.multivariate_normal(negative_center, negative_sigma, size=nc)
    x= np.vstack((pos, neg))
    y = np.hstack((np.ones(nc), -np.ones(nc)))
    
    return x, y
    
def plot2DSet(desc,labels,nom_dataset= "Dataset", avec_grid=True):    
    """ array * array * str * bool-> affichage
        nom_dataset (str): nom du dataset pour la légende
        avec_grid (bool) : True si on veut afficher la grille, False sinon
        la fonction doit utiliser la couleur 'red' pour la classe -1 et 'blue' pour la +1
    """
    data_negatifs = desc[labels == -1]
    data_positifs = desc[labels == 1]

    # Tracé de l'ensemble des exemples :
    plt.scatter(data_negatifs[:,0],data_negatifs[:,1],marker='o', color="red", label='classe -1') # 'o' rouge pour la classe -1
    plt.scatter(data_positifs[:,0],data_positifs[:,1],marker='x', color="blue", label='classe +1') # 'x' bleu pour la classe +1
    
    # Informations d'affichage :
    plt.title(nom_dataset)
    plt.xlabel("x1")
    plt.ylabel("x2")
    plt.legend()
    plt.grid()  # Grille: à mettre, ou pas

    # Visualisation du résultat
    plt.show()

# plot_frontiere:
def plot_frontiere(desc_set, label_set, classifier, step=30):
    """ desc_set * label_set * Classifier * int -> NoneType
        Remarque: le 4e argument est optionnel et donne la "résolution" du tracé: plus il est important
        et plus le tracé de la frontière sera précis.        
        Cette fonction affiche la frontière de décision associée au classifieur
    """
    mmax=desc_set.max(0)
    mmin=desc_set.min(0)
    x1grid,x2grid=np.meshgrid(np.linspace(mmin[0],mmax[0],step),np.linspace(mmin[1],mmax[1],step))
    grid=np.hstack((x1grid.reshape(x1grid.size,1),x2grid.reshape(x2grid.size,1)))
    
    # calcul de la prediction pour chaque point de la grille
    res=np.array([classifier.predict(grid[i,:]) for i in range(len(grid)) ])
    res=res.reshape(x1grid.shape)
    # tracer des frontieres
    # colors[0] est la couleur des -1 et colors[1] est la couleur des +1
    plt.contourf(x1grid,x2grid,res,colors=["darksalmon","skyblue"],levels=[-1000,0,1000])
    
def genere_train_test(desc_set, label_set, n_pos, n_neg):
    """ permet de générer une base d'apprentissage et une base de test
        desc_set: array avec des descriptions
        label_set: array avec les labels correspondants
        n_pos: nombre d'exemples de label +1 à mettre dans la base d'apprentissage
        n_neg: nombre d'exemples de label -1 à mettre dans la base d'apprentissage
        Hypothèses: 
           - desc_set et label_set ont le même nombre de lignes)
           - n_pos et n_neg, ainsi que leur somme, sont inférieurs à n (le nombre d'exemples dans desc_set)
    """
    
    # Get indices of positive and negative examples
    pos_indices = np.where(label_set == 1)[0].tolist()
    neg_indices = np.where(label_set == -1)[0].tolist()
    
    # Sample n_pos positive and n_neg negative for training
    train_pos_indices = random.sample(pos_indices, n_pos)
    train_neg_indices = random.sample(neg_indices, n_neg)
    
    # Combine training indices
    train_indices = train_pos_indices + train_neg_indices
    
    # Get test indices (all indices not in training)
    all_indices = set(range(len(label_set)))
    test_indices = list(all_indices - set(train_indices))
    
    # Extract training and test data
    train_desc = desc_set[train_indices]
    train_label = label_set[train_indices]
    test_desc = desc_set[test_indices]
    test_label = label_set[test_indices]
    
    return (train_desc, train_label), (test_desc, test_label)

def plot2DTrainTestSet(d_train,l_train, d_test,l_test, nom_dataset= "Dataset", avec_grid=True):    
    """ array * array array * array * str * bool-> affichage
        nom_dataset (str): nom du dataset pour la légende
        avec_grid (bool) : True si on veut afficher la grille, False sinon
        la fonction doit utiliser les couleurs suivantes:
        - pour les données d'apprentissage : la couleur 'red' pour la classe -1 et 'blue' pour la +1
        - pour les données de test : la couleur 'jaune' pour la classe -1 et 'verte' pour la +1
    """
    
    # Extract training data by class
    train_negatifs = d_train[l_train == -1]
    train_positifs = d_train[l_train == 1]
    
    # Extract test data by class
    test_negatifs = d_test[l_test == -1]
    test_positifs = d_test[l_test == 1]
    
    # Plot training data
    plt.scatter(train_negatifs[:,0], train_negatifs[:,1], marker='o', color="red", label='train: classe -1')
    plt.scatter(train_positifs[:,0], train_positifs[:,1], marker='x', color="blue", label='train: classe +1')
    
    # Plot test data
    plt.scatter(test_negatifs[:,0], test_negatifs[:,1], marker='s', color="yellow", label='test: classe -1')
    plt.scatter(test_positifs[:,0], test_positifs[:,1], marker='^', color="green", label='test: classe +1')
    
    # Informations d'affichage :
    plt.title(nom_dataset)
    plt.xlabel("x1")
    plt.ylabel("x2")
    plt.legend()
    plt.grid(avec_grid)  # Grille: à mettre, ou pas

    # Visualisation du résultat
    plt.show()

def pca_fit_transform(X, n_components):
    """ Applique une ACP sur X et projette sur n_components axes principaux.
        Retourne (X_proj, mean, components, explained_variance_ratio).
    """
    mean = X.mean(axis=0)
    Xc = X - mean
    U, S, Vt = np.linalg.svd(Xc, full_matrices=False)
    composantes = Vt[:n_components]
    Xp = Xc @ composantes.T
    var_expl = (S ** 2) / (S ** 2).sum()
    return Xp, mean, composantes, var_expl[:n_components]


def pca_transform(X, mean, components):
    """ Projette X sur les composantes principales déjà calculées. """
    return (X - mean) @ components.T


def create_XOR(n, var):
    """ int * float -> tuple[ndarray, ndarray]
        Hyp: n et var sont positifs
        n: nombre de points voulus
        var: variance sur chaque dimension
    """
    
    # Nuages pour la classe +1
    X1 = np.random.multivariate_normal([1,1], np.eye(2)*var, n)
    X2 = np.random.multivariate_normal([0,0], np.eye(2)*var, n)
    
    # Nuages pour la classe -1
    X3 = np.random.multivariate_normal([1,0], np.eye(2)*var, n)
    X4 = np.random.multivariate_normal([0,1], np.eye(2)*var, n)
    
    # Concatener les points des classes
    X = np.vstack((X1, X2, X3, X4))
    
    # Les labels : on a deux classes pour chacune 2n points
    Y = np.array([1]* (2*n) + [-1]* (2*n))
    
    return X, Y
