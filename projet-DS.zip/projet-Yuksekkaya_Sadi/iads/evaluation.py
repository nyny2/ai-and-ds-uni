# -*- coding: utf-8 -*-

"""
Package: iads
File: evaluation.py
Année: LU3IN026 - semestre 2 - 2025-2026, Sorbonne Université
"""

# ---------------------------
# Fonctions d'évaluation de classifieurs

# import externe
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import copy

# ------------------------

def validation_croisee(C, DS, nb_iter, verbose = False):
    """ Classifieur * tuple[array, array] * int -> tuple[ list[float], float, float]
        Arguments:
            - C (Classifieur): un classifieur déjà défini (mais pas entraîné)
            - DS (tuple[array,array]): un tuple composé d'un dataset (data, labels)
            - nb_iter (int): nombre de folds à réaliser
            - verbose: pour afficher des messages au cours de l'exécution
        Retour: tuple[ list[float], float, float]
            - triplet contenant la liste des performances obtenues, la performance moyenne et l'écart type
    """
    perf = []

    X_mel = DS[0]
    Y_mel = DS[1]

    # Découpage en nb_iter folds
    fold_size = len(X_mel) // nb_iter

    for i in range(nb_iter):
        # On copie le classifieur pour ne pas accumuler l'apprentissage d'un fold à l'autre
        clf = copy.deepcopy(C)

        # Bornes du fold de test (le dernier fold récupère le reste)
        start = i * fold_size
        end = start + fold_size if i < nb_iter - 1 else len(X_mel)

        # Séparation test / apprentissage
        X_test = X_mel[start:end]
        Y_test = Y_mel[start:end]
        X_train = np.concatenate((X_mel[:start], X_mel[end:]), axis=0)
        Y_train = np.concatenate((Y_mel[:start], Y_mel[end:]), axis=0)

        clf.train(X_train, Y_train)
        taux = clf.accuracy(X_test, Y_test)

        if verbose:
            print(f"  fold {i+1}/{nb_iter}: accuracy = {taux:.4f}")
        perf.append(taux)

    taux_moyen, taux_ecart = analyse_perfs(perf)
    return perf, taux_moyen, taux_ecart


###################################################################

def analyse_perfs(L):
    """ L : liste de nombres réels non vide
        rend le tuple (moyenne, écart-type)
    """
    moyenne = np.mean(L)
    ecart_type = np.std(L)
    return (moyenne, ecart_type)


###################################################################

def crossval(X, Y, n_iterations, iteration):
    """ Découpe X, Y en n_iterations folds et rend (Xapp, Yapp, Xtest, Ytest)
        pour le fold 'iteration' (0-indexé).
    """
    n = len(X)
    fold_size = n // n_iterations
    start = iteration * fold_size
    end = start + fold_size if iteration < n_iterations - 1 else n
    Xtest = X[start:end]
    Ytest = Y[start:end]
    Xapp = np.concatenate((X[:start], X[end:]), axis=0)
    Yapp = np.concatenate((Y[:start], Y[end:]), axis=0)
    return Xapp, Yapp, Xtest, Ytest


###################################################################

def matrice_confusion(y_true, y_pred, n_classes):
    """ Construit la matrice de confusion (n_classes x n_classes).
        y_true, y_pred : tableaux d'entiers 0..n_classes-1
    """
    M = np.zeros((n_classes, n_classes), dtype=int)
    for vrai, pred in zip(y_true, y_pred):
        M[int(vrai), int(pred)] += 1
    return M


def affiche_matrice_confusion(M, class_names, titre):
    """ Affiche la matrice de confusion M avec les noms de classes. """
    fig, ax = plt.subplots(figsize=(7, 6))
    im = ax.imshow(M, cmap='Blues')
    ax.set_xticks(range(len(class_names)))
    ax.set_yticks(range(len(class_names)))
    ax.set_xticklabels(class_names, rotation=45, ha='right')
    ax.set_yticklabels(class_names)
    ax.set_xlabel("Prédiction")
    ax.set_ylabel("Vraie classe")
    ax.set_title(titre)
    seuil = M.max() / 2
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            ax.text(j, i, str(M[i, j]),
                    ha='center', va='center',
                    color='white' if M[i, j] > seuil else 'black', fontsize=8)
    plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    plt.tight_layout()
    plt.show()


###################################################################

def crossval_strat(X, Y, n_iterations, iteration):
    """ Validation croisée stratifiée : préserve la proportion de chaque classe dans chaque fold. """
    classes = np.unique(Y)
    Xtest_p, Ytest_p = [], []
    Xapp_p, Yapp_p = [], []
    for c in classes:
        idx_c = np.where(Y == c)[0]
        n_c = len(idx_c)
        fold_size_c = n_c // n_iterations
        start = iteration * fold_size_c
        end = start + fold_size_c if iteration < n_iterations - 1 else n_c
        idx_test = idx_c[start:end]
        idx_app = np.concatenate((idx_c[:start], idx_c[end:]))
        Xtest_p.append(X[idx_test]); Ytest_p.append(Y[idx_test])
        Xapp_p.append(X[idx_app]);   Yapp_p.append(Y[idx_app])
    return (np.concatenate(Xapp_p),  np.concatenate(Yapp_p),
            np.concatenate(Xtest_p), np.concatenate(Ytest_p))
